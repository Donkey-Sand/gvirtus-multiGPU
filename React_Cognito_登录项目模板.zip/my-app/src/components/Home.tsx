const Home = () => {
  return (
    <div style={{ padding: 20 }}>
      <h1>🎉 欢迎来到首页！</h1>
    </div>
  );
};
export default Home;