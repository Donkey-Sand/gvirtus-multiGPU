import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Amplify, Auth } from 'aws-amplify';
import axios from 'axios';

Amplify.configure({
  Auth: {
    region: 'ap-northeast-1',
    userPoolId: 'ap-northeast-1_xxxxxxxx',
    userPoolWebClientId: 'xxxxxxxxxxxxxxxxxxxxxxxxxx',
    mandatorySignIn: true
  }
});

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      await Auth.signIn(email, password);
      const session = await Auth.currentSession();
      const token = session.getIdToken().getJwtToken();

      setStatus("✅ 登录成功，正在跳转…");

      await axios.get("https://your-api-id.execute-api.ap-northeast-1.amazonaws.com/history", {
        headers: { Authorization: `Bearer ${token}` }
      });

      navigate("/home");
    } catch (err) {
      console.error(err);
      setStatus("❌ 登录失败：" + err.message);
    }
  };

  return (
    <div style={{ padding: 20, maxWidth: 400 }}>
      <h2>🔐 登录</h2>
      <input type="email" placeholder="邮箱" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="密码" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button onClick={handleLogin}>登录</button>
      <p>{status}</p>
    </div>
  );
};

export default Login;