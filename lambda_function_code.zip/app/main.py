from fastapi import FastAPI, Depends
from datetime import datetime
import boto3
from boto3.dynamodb.conditions import Key
from auth import get_user_id_from_token

app = FastAPI()
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("UserSearchHistory")

@app.post("/search")
def search(keyword: str, user_id: str = Depends(get_user_id_from_token)):
    item = {
        "user_id": user_id,
        "timestamp": datetime.utcnow().isoformat(),
        "keyword": keyword
    }
    table.put_item(Item=item)
    return {"status": "saved", "keyword": keyword}

@app.get("/history")
def get_history(user_id: str = Depends(get_user_id_from_token)):
    result = table.query(
        KeyConditionExpression=Key("user_id").eq(user_id),
        ScanIndexForward=False,
        Limit=50
    )
    return {"history": result["Items"]}