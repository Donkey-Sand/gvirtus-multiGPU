from fastapi import Header, HTTPException
from jose import jwt

def get_user_id_from_token(authorization: str = Header(...)) -> str:
    try:
        token = authorization.split()[1]
        claims = jwt.get_unverified_claims(token)
        return claims["sub"]
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")